#!/usr/bin/env python3
"""Recreate the inert REA npm archive from its checked inventory and seed files.

Python 3.9+ standard library only. Does not extract npm packages, invoke npm,
execute target package code, or upload anything. Default maximum: 16 downloads.

After extracting transfer-seed.zip, run:
  python build-npm-archive.py --output rea-npm-2026-10-14.zip

For local validation without redownloading already verified tarballs:
  python build-npm-archive.py --reuse-tarballs /path/to/archive/npm --output test.zip
"""
import argparse
import concurrent.futures
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import time
import urllib.parse
import urllib.request
import zipfile

BLOCK = 1024 * 1024
SHA256_PATTERN = re.compile(r'^[0-9a-f]{64}$')
HEADERS = {'User-Agent': 'REA-preservation/1.0 (verified artifact preservation)'}


def safe_relative(value):
    if not isinstance(value, str) or '\\' in value:
        raise ValueError('Invalid relative path')
    path = PurePosixPath(value)
    if path.is_absolute() or not path.parts or any(part in ('..', '.') for part in path.parts):
        raise ValueError('Unsafe relative path: ' + value)
    if ':' in value or str(path) != value:
        raise ValueError('Non-normal relative path: ' + value)
    return path


def under(root, relative):
    root = root.resolve()
    result = root.joinpath(*safe_relative(relative).parts).resolve()
    def comparison_path(path):
        value = str(path)
        if os.name == 'nt':
            if value.startswith('\\\\?\\UNC\\'):
                value = '\\\\' + value[8:]
            elif value.startswith('\\\\?\\'):
                value = value[4:]
        return Path(value)
    root_comparison = comparison_path(root)
    result_comparison = comparison_path(result)
    if root_comparison != result_comparison and root_comparison not in result_comparison.parents:
        raise ValueError(f'Path escapes its root: {relative} (root={root}, resolved={result})')
    return result


def hash_file(path):
    digest = hashlib.sha256()
    size = 0
    with path.open('rb') as source:
        for block in iter(lambda: source.read(BLOCK), b''):
            digest.update(block)
            size += len(block)
    return size, digest.hexdigest()


def verify(path, item):
    if not SHA256_PATTERN.fullmatch(item['sha256']):
        raise ValueError('Malformed expected SHA256')
    size, digest = hash_file(path)
    if size != item['bytes'] or digest != item['sha256']:
        raise ValueError('Saved bytes do not match inventory: ' + str(path))
    return path


def allowed_url(value):
    parsed = urllib.parse.urlsplit(value)
    if (parsed.scheme != 'https' or parsed.hostname != 'registry.npmjs.org'
            or parsed.username or parsed.password or parsed.port not in (None, 443)
            or parsed.fragment or parsed.query or not parsed.path.endswith('.tgz')):
        raise ValueError('Unexpected download URL: ' + value)


class RegistryRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, response, code, message, headers, newurl):
        allowed_url(newurl)
        return super().redirect_request(request, response, code, message, headers, newurl)


def fetch(item, download_root, reuse_root):
    allowed_url(item['url'])
    relative = str(safe_relative(item['path']))
    if not relative.endswith('.tgz') or relative.split('/', 1)[0] not in ('dependencies', 'releases'):
        raise ValueError('Unexpected tarball path: ' + relative)
    if not SHA256_PATTERN.fullmatch(item['sha256']) or not isinstance(item['bytes'], int) or item['bytes'] <= 0:
        raise ValueError('Invalid tarball checksum or size: ' + relative)
    if reuse_root is not None:
        return verify(under(reuse_root, relative), item)
    target = under(download_root, relative)
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        return verify(target, item)
    partial = target.with_name(target.name + '.partial')
    opener = urllib.request.build_opener(RegistryRedirectHandler())
    for attempt in range(5):
        try:
            digest = hashlib.sha256()
            size = 0
            request = urllib.request.Request(item['url'], headers=HEADERS)
            with opener.open(request, timeout=120) as response, partial.open('wb') as output:
                allowed_url(response.geturl())
                for block in iter(lambda: response.read(BLOCK), b''):
                    size += len(block)
                    if size > item['bytes']:
                        raise ValueError('Download exceeds expected size: ' + relative)
                    digest.update(block)
                    output.write(block)
            if size != item['bytes'] or digest.hexdigest() != item['sha256']:
                raise ValueError('Download checksum or size mismatch: ' + relative)
            os.replace(partial, target)
            return target
        except Exception:
            if attempt == 4:
                raise
            time.sleep(min(2 ** attempt, 8))
    raise AssertionError('Unreachable')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seed-root', default=str(Path(__file__).resolve().parent))
    parser.add_argument('--work-dir', default='npm-download-work')
    parser.add_argument('--output', default='rea-npm-2026-10-14.zip')
    parser.add_argument('--workers', type=int, default=16, choices=range(1, 17))
    parser.add_argument('--reuse-tarballs', help='Verify and reuse an existing npm archive without network requests')
    args = parser.parse_args()
    seed_root = Path(args.seed_root).resolve()
    npm_seed = under(seed_root, 'npm')
    download_root = Path(args.work_dir).resolve() / 'npm'
    download_root.mkdir(parents=True, exist_ok=True)
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        raise FileExistsError('Output already exists; choose a new output: ' + str(output))
    reuse_root = Path(args.reuse_tarballs).resolve() if args.reuse_tarballs else None
    seed_manifest = json.loads((seed_root / 'seed-file-checksums.json').read_text(encoding='utf-8'))
    members = {}
    member_records = {}
    for item in seed_manifest['files']:
        relative = str(safe_relative(item['path']))
        if not relative.startswith('npm/') or relative.endswith('.tgz'):
            raise ValueError('Unexpected seed member: ' + relative)
        path = verify(under(seed_root, relative), item)
        if relative in members:
            raise ValueError('Duplicate seed path: ' + relative)
        members[relative] = path
        member_records[relative] = item
    inventory = json.loads((npm_seed / 'inventory.json').read_text(encoding='utf-8'))
    items = inventory['items']
    if len(items) != 586 or inventory['npmPackageVersions'] != 34 or inventory['uniqueDependencyTarballs'] != 552:
        raise ValueError('This snapshot must have 34 REA packages and 552 dependency tarballs')
    if sum(item['bytes'] for item in items) != inventory['totalBytes']:
        raise ValueError('Inventory size summary mismatch')
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = {pool.submit(fetch, item, download_root, reuse_root): item for item in items}
        for index, future in enumerate(concurrent.futures.as_completed(futures), 1):
            item = futures[future]
            path = future.result()
            relative = 'npm/' + item['path']
            if relative in members:
                raise ValueError('Duplicate archive path: ' + relative)
            members[relative] = path
            member_records[relative] = {'path': relative, 'bytes': item['bytes'], 'sha256': item['sha256']}
            if index % 25 == 0 or index == len(items):
                print(f'Verified {index}/{len(items)} tarballs', flush=True)
    temporary_output = output.with_name(output.name + '.partial')
    with zipfile.ZipFile(temporary_output, 'w', compression=zipfile.ZIP_STORED, allowZip64=True) as archive:
        for relative in sorted(members):
            info = zipfile.ZipInfo(relative, date_time=(2026, 10, 14, 0, 0, 0))
            info.compress_type = zipfile.ZIP_STORED
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.file_size = member_records[relative]['bytes']
            with members[relative].open('rb') as source, archive.open(info, 'w') as destination:
                shutil.copyfileobj(source, destination, length=BLOCK)
    os.replace(temporary_output, output)
    archive_size, archive_sha = hash_file(output)
    report = {
        'completedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'archive': output.name, 'archiveBytes': archive_size, 'archiveSHA256': archive_sha,
        'zipCompression': 'ZIP_STORED', 'files': len(members), 'tarballs': len(items),
        'seedFiles': len(seed_manifest['files']), 'allExpectedSHA256Verified': True,
        'targetCodeExecuted': False, 'maximumParallelDownloads': args.workers,
        'networkUsed': reuse_root is None,
        'memberChecksums': [member_records[name] for name in sorted(member_records)],
    }
    report_path = output.with_suffix('.report.json')
    report_path.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    checksums = output.with_suffix('.SHA256SUMS.txt')
    checksums.write_text(archive_sha + '  ' + output.name + '\n', encoding='utf-8')
    print(json.dumps({key: value for key, value in report.items() if key != 'memberChecksums'}, indent=2), flush=True)
    print('Report: ' + str(report_path), flush=True)


if __name__ == '__main__':
    main()
