"""Verify saved npm tarballs and seed an isolated npm cache without lifecycle scripts.

Requires Python 3.9+ and npm. Does not install or execute REA or dependencies.
Usage: python prepare-offline-cache.py --cache /absolute/path/to/npm-cache
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cache', required=True, help='Isolated npm cache directory to create or populate')
    parser.add_argument('--include-historical-packages', action='store_true',
                        help='Also cache all 34 original REA package tarballs (their old dependencies are not all mirrored)')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    inventory = json.loads((root / 'inventory.json').read_text(encoding='utf-8'))
    npm = shutil.which('npm.cmd' if os.name == 'nt' else 'npm')
    if not npm:
        parser.error('npm is not on PATH; install a compatible Node.js and npm runtime first')
    cache = Path(args.cache).resolve()
    cache.mkdir(parents=True, exist_ok=True)
    paths = []
    for item in inventory['items']:
        if item['kind'] != 'locked-dependency' and not args.include_historical_packages:
            continue
        path = (root / item['path']).resolve()
        if root not in path.parents:
            raise ValueError('Invalid tarball path outside archive: ' + item['path'])
        with path.open('rb') as source:
            digest = hashlib.sha256()
            for chunk in iter(lambda: source.read(1024 * 1024), b''):
                digest.update(chunk)
        if digest.hexdigest() != item['sha256']:
            raise ValueError('SHA256 mismatch: ' + item['path'])
        paths.append(str(path))
    env = dict(os.environ, NPM_CONFIG_IGNORE_SCRIPTS='true', NPM_CONFIG_UPDATE_NOTIFIER='false',
               NPM_CONFIG_OFFLINE='true', NPM_CONFIG_AUDIT='false', NPM_CONFIG_FUND='false')
    for start in range(0, len(paths), 25):
        batch = paths[start:start + 25]
        subprocess.run([npm, 'cache', 'add', *batch, '--cache', str(cache), '--offline',
                        '--ignore-scripts', '--no-audit', '--no-fund'], check=True, env=env)
        print(f'Cached {min(start + 25, len(paths))}/{len(paths)} verified tarballs', flush=True)
    print('Offline cache ready: ' + str(cache))


if __name__ == '__main__':
    main()
